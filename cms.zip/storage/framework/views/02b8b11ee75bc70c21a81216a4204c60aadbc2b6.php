<?php $__env->startSection('title', 'Admin DashBoard'); ?>
<?php $__env->startSection('content'); ?>

    <div class="content-wrapper">
        <section class="content">
            <div class="container-fluid">
                <h2 class="text-center display-4"> Search</h2>
                <form action="<?php echo e(url()->current()); ?>">
                    <div class="row">
                        <div class="col-md-10 offset-md-1">
                            <div class="row">
                                <div class="col-6">
                                    <div class="form-group">
                                        <label> Type:</label>
                                        <select class="select2" name="type" data-placeholder="Any" style="width: 100%;">
                                            <option <?php if(request('type') == 'Seller'): ?> selected <?php endif; ?>>Seller</option>
                                            <option <?php if(request('type') == 'Land loard'): ?> selected <?php endif; ?>>Land loard</option>

                                        </select>
                                    </div>
                                </div>
                                <div class="col-6">
                                    <div class="form-group">
                                        <label>Price Range</label>
                                        <select class="select2" name="budget" style="width: 100%;">
                                            <option <?php if(request('budget') == '10k-15k'): ?> selected <?php endif; ?>>10k-15k</option>
                                            <option <?php if(request('budget') == '15k-20k'): ?> selected <?php endif; ?>>15k-20k</option>
                                            <option <?php if(request('budget') == '20k-30k'): ?> selected <?php endif; ?>>20k-30k</option>
                                            <option <?php if(request('budget') == '30k-50k'): ?> selected <?php endif; ?>>30k-50k</option>
                                            <option <?php if(request('budget') == '50k-80k'): ?> selected <?php endif; ?>>50k-80k</option>
                                        </select>
                                    </div>
                                </div>

                            </div>
                            <div class="form-group">
                                <label>choice apartment</label>
                                <select class="select2" name="apartment" style="width: 100%;">
                                    <option <?php if(request('apartment') == 'Studio'): ?> selected <?php endif; ?>>Studio</option>
                                    <option <?php if(request('apartment') == '1 BHK'): ?> selected <?php endif; ?>>1 BHK</option>
                                    <option <?php if(request('apartment') == '2 BHK'): ?> selected <?php endif; ?>>2 BHK</option>
                                    <option <?php if(request('apartment') == '3 BHK'): ?> selected <?php endif; ?>>3 BHK</option>
                                    <option <?php if(request('apartment') == '4 BHK'): ?> selected <?php endif; ?>>4 BHK</option>
                                    <option <?php if(request('apartment') == '5 BHK'): ?> selected <?php endif; ?>>5 BHK</option>
                                    <option <?php if(request('apartment') == 'Penthouse'): ?> selected <?php endif; ?>>Penthouse</option>
                                </select>
                            </div>

                            <button type="Search" class="btn btn-primary">Search</button>

                        </div>
                    </div>
                </form>
            </div>
        </section>
        <?php if(count($search)>=0): ?>
        <section class="content">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-12">
                        <div class="card">
                            <div class="card-body">
                                <table id="example1" class="table table-bordered table-striped">
                                    <thead>
                                        <tr>
                                            <th>Date</th>
                                            <th>Name</th>
                                            <th>Number</th>
                                            <th>Apartment</th>
                                            <th>Price</th>
                                            <th>Location</th>
                                            <th>Avalibity</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $search; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $seller): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($seller['date']); ?></td>
                                            <?php if(request('type') == 'Seller'): ?>
                                            <td><strong><a href="<?php echo e(url('admin/seller/profile/'.$seller['id'])); ?>"><?php echo e($seller['name']); ?></a></strong></td>
                                            <?php else: ?>
                                            <td><strong><a href="<?php echo e(url('admin/landloard/profile/'.$seller['id'])); ?>"><?php echo e($seller['name']); ?></a></strong></td>
                                            <?php endif; ?>
                                            <td><?php echo e($seller['phone']); ?></td>
                                            <td><?php echo e($seller['apartment']); ?></td>
                                            <td><?php echo e($seller['budget']); ?></td>
                                            <td><?php echo e($seller['society']); ?></td>
                                            <?php if($seller['status']): ?>
                                            <td style="background-color: #dc3545;color:white"><b>No</b></td>
                                                <?php else: ?>
                                                <td style="background-color: #28a745;color:white"><b>Yes</b></td>
                                            <?php endif; ?>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>

                                </table>
                            </div>

                        </div>

                    </div>

                </div>

            </div>

        </section>
        <?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>
<script src="<?php echo e(asset('admin/plugins/jquery/jquery.min.js')); ?>"></script>
<script src="<?php echo e(asset('admin/plugins/bootstrap/js/bootstrap.bundle.min.js')); ?>"></script>
<script src="<?php echo e(asset('admin/plugins/select2/js/select2.full.min.js')); ?>"></script>
<script src="<?php echo e(asset('admin/plugins/datatables/jquery.dataTables.min.js')); ?>"></script>
<script src="<?php echo e(asset('admin/plugins/datatables-bs4/js/dataTables.bootstrap4.min.js')); ?>"></script>
<script src="<?php echo e(asset('admin/plugins/datatables-responsive/js/dataTables.responsive.min.js')); ?>"></script>
<script src="<?php echo e(asset('admin/plugins/datatables-responsive/js/responsive.bootstrap4.min.js')); ?>"></script>
<script src="<?php echo e(asset('admin/plugins/datatables-buttons/js/dataTables.buttons.min.js')); ?>"></script>
<script src="<?php echo e(asset('admin/plugins/datatables-buttons/js/buttons.bootstrap4.min.js')); ?>"></script>
<script src="<?php echo e(asset('admin/plugins/jszip/jszip.min.js')); ?>"></script>
<script src="<?php echo e(asset('admin/plugins/pdfmake/pdfmake.min.js')); ?>"></script>
<script src="<?php echo e(asset('admin/plugins/pdfmake/vfs_fonts.js')); ?>"></script>
<script src="<?php echo e(asset('admin/plugins/datatables-buttons/js/buttons.html5.min.js')); ?>"></script>
<script src="<?php echo e(asset('admin/plugins/datatables-buttons/js/buttons.print.min.js')); ?>"></script>
<script src="<?php echo e(asset('admin/plugins/datatables-buttons/js/buttons.colVis.min.js')); ?>"></script>
<script src="<?php echo e(asset('admin/dist/js/adminlte.min2167.js?v=3.2.0')); ?>"></script>
<script src="<?php echo e(asset('admin/dist/js/demo.js')); ?>"></script>
<script>
    $(function() {
        $("#example1").DataTable({
            "responsive": true,
            "lengthChange": false,
            "autoWidth": false,
        }).container().appendTo('#example1_wrapper .col-md-6:eq(0)');
        $('#example2').DataTable({
            "paging": true,
            "lengthChange": false,
            "searching": false,
            "ordering": true,
            "info": true,
            "autoWidth": false,
            "responsive": true,
        });
    });
</script>
<script>
    $(function() {
        $('.select2').select2()
    });
</script>
</body>


</html>

<?php echo $__env->make('admin.layouts.admin_layouts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\Akash\git project\cms\resources\views/admin/dashbord.blade.php ENDPATH**/ ?>