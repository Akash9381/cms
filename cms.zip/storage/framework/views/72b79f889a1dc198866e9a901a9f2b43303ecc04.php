<?php $__env->startSection('title','Tenant'); ?>
<?php $__env->startSection('content'); ?>
        <div class="content-wrapper">

            <section class="content-header">
                <div class="container-fluid">
                    <div class="row mb-2">
                        <div class="col-sm-6">
                            <h1>Tenant</h1>
                        </div>
                        <div class="col-sm-6">
                            <ol class="breadcrumb float-sm-right">
                                <button type="button" class="btn btn-block btn-primary"> <a class="text-white"
                                    href="<?php echo e(url('admin/tenant/form')); ?>"><i
                                        class="nav-icon fas fa-plus"></i> &nbsp;Add New</a></button>
                            </ol>
                        </div>
                        <?php if(\Spatie\Permission\PermissionServiceProvider::bladeMethodWrapper('hasRole', 'employee')): ?>
                        <input type="hidden" id="btnhide" value="employee">
                        <?php endif; ?>
                    </div>
                    <div x-data="{show: true}" x-init="setTimeout(() => show = false, 5000)" x-show="show">
                        <?php if(session()->has('success')): ?>
                        <div class="col-sm-12 alert alert-info">
                            <?php echo e(session()->get('success')); ?>

                        </div>
                        <?php endif; ?>
                        <?php if(session()->has('error')): ?>
                        <div class="col-sm-12 alert alert-danger">
                            <?php echo e(session()->get('error')); ?>

                        </div>
                        <?php endif; ?>
                    </div>
                </div>
            </section>

            <section class="content">
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-12">
                            <div class="card">

                                <div class="card-body">
                                    <table id="example1" class="table table-bordered table-striped">
                                        <thead>
                                            <tr>
                                                <th>Date</th>
                                                <th>Name</th>
                                                <th>Number</th>
                                                <th>Apartment </th>
                                                <th>Followup Call</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php $__currentLoopData = $tenents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tenent): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <tr>
                                                    <td><?php echo e($tenent['date']); ?></td>
                                                    <td><strong><a href="<?php echo e(url('admin/tenant/profile/'.$tenent['id'])); ?>"><?php echo e($tenent['name']); ?></a></strong></td>
                                                    <td><?php echo e($tenent['phone']); ?></td>
                                                    <td><?php echo e($tenent['apartment']); ?></td>
                                                    <td><?php echo e($tenent['schedule']); ?></td>
                                                </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>

                                    </table>
                                </div>

                            </div>

                        </div>

                    </div>

                </div>

            </section>

        </div>
<?php $__env->stopSection(); ?>

    <script src="<?php echo e(asset('admin/plugins/jquery/jquery.min.js')); ?>"></script>
    <script src="<?php echo e(asset('admin/plugins/bootstrap/js/bootstrap.bundle.min.js')); ?>"></script>
    <script src="<?php echo e(asset('admin/plugins/datatables/jquery.dataTables.min.js')); ?>"></script>
    <script src="<?php echo e(asset('admin/plugins/datatables-bs4/js/dataTables.bootstrap4.min.js')); ?>"></script>
    <script src="<?php echo e(asset('admin/plugins/datatables-responsive/js/dataTables.responsive.min.js')); ?>"></script>
    <script src="<?php echo e(asset('admin/plugins/datatables-responsive/js/responsive.bootstrap4.min.js')); ?>"></script>
    <script src="<?php echo e(asset('admin/plugins/datatables-buttons/js/dataTables.buttons.min.js')); ?>"></script>
    <script src="<?php echo e(asset('admin/plugins/datatables-buttons/js/buttons.bootstrap4.min.js')); ?>"></script>
    <script src="<?php echo e(asset('admin/plugins/jszip/jszip.min.js')); ?>"></script>
    <script src="<?php echo e(asset('admin/plugins/pdfmake/pdfmake.min.js')); ?>"></script>
    <script src="<?php echo e(asset('admin/plugins/pdfmake/vfs_fonts.js')); ?>"></script>
    <script src="<?php echo e(asset('admin/plugins/datatables-buttons/js/buttons.html5.min.js')); ?>"></script>
    <script src="<?php echo e(asset('admin/plugins/datatables-buttons/js/buttons.print.min.js')); ?>"></script>
    <script src="<?php echo e(asset('admin/plugins/datatables-buttons/js/buttons.colVis.min.js')); ?>"></script>
    <script src="<?php echo e(asset('admin/dist/js/adminlte.min2167.js?v=3.2.0')); ?>"></script>
    <script src="<?php echo e(asset('admin/dist/js/demo.js')); ?>"></script>

    <script>
        $(function () {
            $("#example1").DataTable({
                "responsive": true, "lengthChange": false, "autoWidth": false,
                "buttons": ["excel", "pdf"]
            }).buttons().container().appendTo('#example1_wrapper .col-md-6:eq(0)');
            $('#example2').DataTable({
                "paging": true,
                "lengthChange": false,
                "searching": false,
                "ordering": true,
                "info": true,
                "autoWidth": false,
                "responsive": true,
            });
        });
        $(document).ready(function(){
            var btnhide = $("#btnhide").val();
            if(btnhide=='employee'){
                $('.dt-buttons').hide();
            }
        });
    </script>
</body>


</html>

<?php echo $__env->make('admin.layouts.admin_layouts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\Akash\git project\cms\resources\views/admin/tenent/tenent.blade.php ENDPATH**/ ?>