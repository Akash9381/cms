<?php $__env->startSection('title','Land Loard Profile'); ?>
<?php $__env->startSection('content'); ?>

        <div class="content-wrapper">

            <section class="content-header">
                <div class="container-fluid">
                    <div class="row mb-2">
                        <div class="col-sm-6">
                            <h1>Profile</h1>
                        </div>
                        <div class="col-sm-6">
                            <ol class="breadcrumb float-sm-right">
                                <div class="btn-group btn-group-sm">
                                    <a href="<?php echo e(url('admin/landloard/form/'.$landloardprofile['id'])); ?>" class="btn btn-info"><i class="fas fa-edit"></i></a>
                                    <?php if(\Spatie\Permission\PermissionServiceProvider::bladeMethodWrapper('hasRole', 'admin')): ?>
                                    <a href="<?php echo e(url('admin/landloard/delete/'.$landloardprofile['id'])); ?>" onclick="return confirm('Are you Sure to Delete this Landloard?')" class="btn btn-danger"><i class="fas fa-trash"></i></a>
                                    <?php endif; ?>
                                </div>
                            </ol>
                        </div>
                    </div>
                </div>
            </section>

            <section class="content">
                <div class="container-fluid">
                    <div class="row">

                        <div class="col-md-12">

                            <div class="card card-primary">
                                <div class="card-header">
                                    <h3 class="card-title">Contact Details</h3>
                                </div>

                                <form>
                                    <div class="card-body">

                                        <div class="row">
                                            <div class="col-md-3">
                                                <div class="form-group">
                                                    <label for="exampleInputName">Full Name</label>
                                                    <p><?php echo e($landloardprofile['name']); ?></p>
                                                </div>
                                            </div>

                                            <div class="col-md-3">
                                                <div class="form-group">
                                                    <label for="exampleInputEmail1">Email address</label>
                                                    <p><?php echo e($landloardprofile['email']); ?></p>
                                                </div>
                                            </div>

                                            <div class="col-md-3">
                                                <div class="form-group">
                                                    <label for="exampleInputNumber">Contact Number</label>
                                                    <p><?php echo e($landloardprofile['phone']); ?></p>
                                                </div>
                                            </div>

                                            <div class="col-md-3">
                                                <div class="form-group">
                                                    <label for="exampleInputNumber">Date</label>
                                                    <div class="input-group date" id="reservationdate"
                                                        data-target-input="nearest">
                                                        <p><?php echo e($landloardprofile['date']); ?></p>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </section>


            <section class="content">
                <div class="container-fluid">
                    <div class="row">

                        <div class="col-md-12">

                            <div class="card card-primary">
                                <div class="card-header">
                                    <h3 class="card-title">Apartment Details</h3>
                                </div>

                                <form>
                                    <div class="card-body">

                                        <div class="row">
                                            <div class="col-md-3">
                                                <div class="form-group">
                                                    <label>Apartment</label>
                                                    <p><?php echo e($landloardprofile['apartment']); ?></p>
                                                </div>
                                            </div>

                                            <div class="col-md-3">
                                                <div class="form-group">
                                                    <label for="inputSq.ft">Sq.ft</label>
                                                    <p><?php echo e($landloardprofile['area']); ?></p>
                                                </div>
                                            </div>

                                            <div class="col-md-3">
                                                <div class="form-group">
                                                    <label for="inputSociety">Society</label>
                                                    <p><?php echo e($landloardprofile['society']); ?></p>
                                                </div>
                                            </div>

                                            <div class="col-md-3">
                                                <div class="form-group">
                                                    <label for="inputBlock">Block/Tower</label>
                                                    <p><?php echo e($landloardprofile['block']); ?></p>
                                                </div>
                                            </div>

                                        </div>


                                        <div class="row">

                                            <div class="col-md-3">
                                                <div class="form-group">
                                                    <label for="Floor">Floor</label>
                                                    <p><?php echo e($landloardprofile['floor']); ?></p>
                                                </div>
                                            </div>

                                            <div class="col-md-3">
                                                <div class="form-group">
                                                    <label for="Flat No">Flat No</label>
                                                    <p><?php echo e($landloardprofile['flat_no']); ?></p>
                                                </div>
                                            </div>

                                            <div class="col-md-3">
                                                <div class="form-group">
                                                    <label for="inputBathroom">Bathroom</label>
                                                    <p><?php echo e($landloardprofile['bathroom']); ?></p>
                                                </div>
                                            </div>

                                            <div class="col-md-3">
                                                <div class="form-group">
                                                    <label for="inputbalcony">Balcony</label>
                                                    <p><?php echo e($landloardprofile['balcony']); ?></p>
                                                </div>
                                            </div>
                                            <input type="hidden" id="buyerid" value="<?php echo e($landloardprofile['id']); ?>">
                                        </div>


                                        <div class="row">

                                            <div class="col-md-3">
                                                <div class="form-group">
                                                    <label for="Lift">Lift</label>
                                                    <p><?php echo e($landloardprofile['lift']); ?></p>
                                                </div>
                                            </div>

                                            <div class="col-md-3">
                                                <div class="form-group">
                                                    <label for="Flat No">Parking</label>
                                                    <p><?php echo e($landloardprofile['parking']); ?></p>
                                                </div>
                                            </div>

                                            <div class="col-md-3">
                                                <div class="form-group">
                                                    <label>Apartment Type</label>
                                                    <p><?php echo e($landloardprofile['apartment_type']); ?></p>
                                                </div>
                                            </div>

                                            <div class="col-md-3">
                                                <div class="form-group">
                                                    <label for="inputSq.ft">Rental/Sell Price</label>
                                                    <p><?php echo e($landloardprofile['budget']); ?> lakh</p>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="card-footer">
                                        <input id="chkbtn" type="checkbox" data-toggle="switchbutton" <?php if($landloardprofile['status']==0): ?>
                                        checked
                                        <?php endif; ?>  data-onlabel="Available"
                                            data-offlabel="Boked" data-onstyle="success" data-offstyle="danger">
                                            <label style="color: red;display:none" id="booked" >Booked successfully</label>
                                            <label style="color:green;display:none" id="available">Available successfully</label>
                                            <label style="color:red;display:none" id="someerror" >Something went wrong</label>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
        </div>
<?php $__env->stopSection(); ?>


    <script src="<?php echo e(asset('admin/plugins/jquery/jquery.min.js')); ?>"></script>
    <script src="<?php echo e(asset('admin/plugins/bootstrap/js/bootstrap.bundle.min.js')); ?>"></script>
    <script src="<?php echo e(asset('admin/plugins/jquery-validation/jquery.validate.min.js')); ?>"></script>
    <script src="<?php echo e(asset('admin/plugins/jquery-validation/additional-methods.min.js')); ?>"></script>
    <script src="<?php echo e(asset('admin/dist/js/adminlte.min2167.js?v=3.2.0')); ?>"></script>
    <script src="<?php echo e(asset('admin/dist/js/demo.js')); ?>"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.1/jquery.min.js"></script>

    <script>
        $(document).ready(function(){
            $("#chkbtn").change(function(){
                var ischecked = 1;
                var id = $("#buyerid").val();
                if(this.checked){
                    ischecked = 0;
                }
                $.ajax({
                    url:'/admin/landlord/booked',
                    type:'get',
                    data:{id:id,status:ischecked},
                    success:function(res){
                        if(res.success){
                           if(ischecked==0){
                            $("#available").show();
                            $("#booked").hide();
                            $("#someerror").hide();
                        }else{
                               $("#available").hide();
                               $("#someerror").hide();
                               $("#booked").show();
                            }
                        }else{
                            $("#someerror").show();
                            $("#available").hide();
                            $("#booked").hide();
                        }
                    }
                })
            });
        })
        $(function () {
            $.validator.setDefaults({
                submitHandler: function () {
                    alert("Form successful submitted!");
                }
            });
            $('#quickForm').validate({
                rules: {
                    email: {
                        required: true,
                        email: true,
                    },
                    password: {
                        required: true,
                        minlength: 5
                    },
                    terms: {
                        required: true
                    },
                },
                messages: {
                    email: {
                        required: "Please enter a email address",
                        email: "Please enter a valid email address"
                    },
                    password: {
                        required: "Please provide a password",
                        minlength: "Your password must be at least 5 characters long"
                    },
                    terms: "Please accept our terms"
                },
                errorElement: 'span',
                errorPlacement: function (error, element) {
                    error.addClass('invalid-feedback');
                    element.closest('.form-group').append(error);
                },
                highlight: function (element, errorClass, validClass) {
                    $(element).addClass('is-invalid');
                },
                unhighlight: function (element, errorClass, validClass) {
                    $(element).removeClass('is-invalid');
                }
            });
        });
    </script>

</html>

<?php echo $__env->make('admin.layouts.admin_layouts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\Akash\git project\cms\resources\views/admin/landloard/landloard-profile.blade.php ENDPATH**/ ?>