<nav class="main-header navbar navbar-expand navbar-white navbar-light">

    <ul class="navbar-nav">
        <li class="nav-item">
            <a class="nav-link" data-widget="pushmenu" href="#" role="button"><i class="fas fa-bars"></i></a>
        </li>
        

    </ul>

    <ul class="navbar-nav ml-auto">

        <li class="nav-item dropdown">
            <a class="nav-link" data-toggle="dropdown" href="#">
                <i class="far fa-bell fa-2x"></i>
                <?php if(AllNotification()>0): ?>
                <span class="badge badge-warning navbar-badge"><?php echo e(AllNotification()); ?></span>

                <?php endif; ?>
            </a>
            <div class="dropdown-menu dropdown-menu-lg dropdown-menu-right">
                <span class="dropdown-item dropdown-header"><?php echo e(AllNotification()); ?> Notifications</span>
                <div class="dropdown-divider"></div>
                <?php if(TenentCount()>0): ?>
                <a href="<?php echo e(url('admin/notification?tenant='.TenentCount())); ?>" class="dropdown-item">
                    
                    <i class="nav-icon fas fa-user-circle"></i><span class="mx-3">
                     <?php echo e(TenentCount()); ?> Tenant</span>
                    
                </a>
                <?php endif; ?>
                <div class="dropdown-divider"></div>
                <?php if(BuyerCount()>0): ?>
                <a href="<?php echo e(url('admin/notification?buyer='.BuyerCount())); ?>" class="dropdown-item">
                    
                    <i class="nav-icon fas fa-user-circle"></i><span class="mx-3">
                     <?php echo e(BuyerCount()); ?> Buyer</span>
                    
                </a>
                <?php endif; ?>
                
                <div class="dropdown-divider"></div>
                <a href="<?php echo e(url('admin/notification')); ?>" class="dropdown-item dropdown-footer">See All Notifications</a>
            </div>
        </li>


    </ul>
</nav>
<?php /**PATH G:\Akash\git project\cms\resources\views/admin/layouts/header.blade.php ENDPATH**/ ?>