<?php $__env->startSection('title','Seller Form'); ?>
<?php $__env->startSection('content'); ?>


        <div class="content-wrapper">

            <section class="content-header">
                <div class="container-fluid">
                    <div class="row mb-2">
                        <div class="col-sm-6">
                            <h1>New Query Form</h1>
                        </div>
                    </div>
                </div>
            </section>

            <section class="content">
                <div class="container-fluid">
                    <div class="row">

                        <div class="col-md-12">
                            <?php if(session()->has('success')): ?>
                            <div class="col-sm-12 alert alert-success">
                                <?php echo e(session()->get('success')); ?>

                            </div>
                            <?php endif; ?>
                            <?php if(session()->has('error')): ?>
                            <div class="col-sm-12 alert alert-danger">
                                <?php echo e(session()->get('error')); ?>

                            </div>
                            <?php endif; ?>
                            <div class="card card-primary">
                                <div class="card-header">
                                    <h3 class="card-title">Contact Details</h3>
                                </div>
                                <?php if(isset($sellerdata)): ?>
                                <form method="POST" action="<?php echo e(url('admin/submitseller/'.$sellerdata['id'])); ?>">
                                    <?php else: ?>
                                    <form method="POST" action="<?php echo e(url('admin/submitseller')); ?>">
                                <?php endif; ?>
                                    <?php echo csrf_field(); ?>
                                    <div class="card-body">

                                        <div class="row">
                                            <div class="col-md-3">
                                                <div class="form-group">
                                                    <label for="exampleInputName">Full Name</label>
                                                    <input type="text" name="name" <?php if(isset($sellerdata)): ?>
                                                   value ="<?php echo e($sellerdata['name']); ?>"
                                                <?php endif; ?> class="form-control" id="exampleInputName"
                                                        placeholder="Enter Name">
                                                </div>
                                            </div>

                                            <div class="col-md-3">
                                                <div class="form-group">
                                                    <label for="exampleInputEmail1">Email address</label>
                                                    <input type="email" <?php if(isset($sellerdata)): ?>
                                                    value ="<?php echo e($sellerdata['email']); ?>"
                                                 <?php endif; ?> name="email" class="form-control"
                                                        id="exampleInputEmail1" placeholder="Enter email">
                                                </div>
                                            </div>

                                            <div class="col-md-3">
                                                <div class="form-group">
                                                    <label for="exampleInputNumber">Contact Number</label>
                                                    <input type="tel" <?php if(isset($sellerdata)): ?>
                                                    value ="<?php echo e($sellerdata['phone']); ?>"
                                                 <?php endif; ?> name="phone" pattern="[789][0-9]{9}" class="form-control"
                                                        id="exampleInputNumber" placeholder="Contact Number">
                                                </div>
                                            </div>

                                            <div class="col-md-3">
                                                <div class="form-group">
                                                    <label for="exampleInputNumber">Date</label>
                                                    <div class="input-group date" id="reservationdate"
                                                        data-target-input="nearest">
                                                        <input type="text" name="date"
                                                        <?php if(isset($sellerdata)): ?>
                                                        value="<?php echo e(\Carbon\Carbon::parse($sellerdata->date)->format('m/d/Y')); ?>"
                                                <?php endif; ?>
                                                            class="form-control datetimepicker-input"
                                                            data-target="#reservationdate" />
                                                        <div class="input-group-append" data-target="#reservationdate"
                                                            data-toggle="datetimepicker">
                                                            <div class="input-group-text"><i
                                                                    class="fa fa-calendar"></i></div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                
                            </div>
                        </div>
                    </div>
                </div>
            </section>


            <section class="content">
                <div class="container-fluid">
                    <div class="row">

                        <div class="col-md-12">

                            <div class="card card-primary">
                                <div class="card-header">
                                    <h3 class="card-title">Apartment Details</h3>
                                </div>

                                
                                    <div class="card-body">

                                        <div class="row">
                                            <div class="col-md-6">
                                                <div class="form-group">
                                                    <label>Apartment</label>
                                                    <select class="form-control select2" name="apartment" style="width: 100%;">
                                                        <option <?php if(isset($sellerdata)): ?> <?php if($sellerdata['apartment']=='Studio'): ?>
                                                        selected
                                                    <?php endif; ?> <?php endif; ?> >Studio</option>
                                                    <option <?php if(isset($sellerdata)): ?> <?php if($sellerdata['apartment']=='1 BHK'): ?>
                                                        selected
                                                    <?php endif; ?> <?php endif; ?>>1 BHK</option>
                                                    <option <?php if(isset($sellerdata)): ?> <?php if($sellerdata['apartment']=='2 BHK'): ?>
                                                        selected
                                                    <?php endif; ?> <?php endif; ?>>2 BHK</option>
                                                    <option <?php if(isset($sellerdata)): ?> <?php if($sellerdata['apartment']=='3 BHK'): ?>
                                                        selected
                                                    <?php endif; ?> <?php endif; ?>>3 BHK</option>
                                                    <option <?php if(isset($sellerdata)): ?> <?php if($sellerdata['apartment']=='4 BHK'): ?>
                                                        selected
                                                    <?php endif; ?> <?php endif; ?>>4 BHK</option>
                                                    <option <?php if(isset($sellerdata)): ?> <?php if($sellerdata['apartment']=='5 BHK'): ?>
                                                        selected
                                                    <?php endif; ?> <?php endif; ?>>5 BHK</option>
                                                    <option <?php if(isset($sellerdata)): ?> <?php if($sellerdata['apartment']=='Penthouse'): ?>
                                                        selected
                                                    <?php endif; ?> <?php endif; ?>>Penthouse</option>
                                                    </select>
                                                </div>
                                            </div>

                                            <div class="col-md-6">
                                                <div class="form-group">
                                                    <label for="inputSq.ft">Sq.ft</label>
                                                    <input type="text" id="" <?php if(isset($sellerdata)): ?>
                                                    value="<?php echo e($sellerdata['area']); ?>"
                                                    <?php endif; ?>  name="area" class="form-control">
                                                </div>
                                            </div>

                                        </div>


                                        <div class="row">
                                            <div class="col-md-3">
                                                <div class="form-group">
                                                    <label for="inputSociety">Society</label>
                                                    <input type="text" id=""
                                                    <?php if(isset($sellerdata)): ?>
                                                    value="<?php echo e($sellerdata['society']); ?>"
                                                    <?php endif; ?>
                                                     name="society" class="form-control">
                                                </div>
                                            </div>

                                            <div class="col-md-3">
                                                <div class="form-group">
                                                    <label for="inputBlock">Block/Tower</label>
                                                    <input type="text" id=""
                                                    <?php if(isset($sellerdata)): ?>
                                                    value="<?php echo e($sellerdata['block']); ?>"
                                                    <?php endif; ?>
                                                     name="block" class="form-control">
                                                </div>
                                            </div>

                                            <div class="col-md-3">
                                                <div class="form-group">
                                                    <label for="Floor">Floor</label>
                                                    <input type="text" id="" name="floor"
                                                    <?php if(isset($sellerdata)): ?>
                                                    value="<?php echo e($sellerdata['floor']); ?>"
                                                    <?php endif; ?> class="form-control">
                                                </div>
                                            </div>

                                            <div class="col-md-3">
                                                <div class="form-group">
                                                    <label for="Flat No">Flat No</label>
                                                    <input type="text" id=""
                                                    <?php if(isset($sellerdata)): ?>
                                                    value="<?php echo e($sellerdata['flat_no']); ?>"
                                                    <?php endif; ?>
                                                     name="flat_no" class="form-control">
                                                </div>
                                            </div>
                                        </div>


                                        <div class="row">
                                            <div class="col-md-3">
                                                <div class="form-group">
                                                    <label for="inputBathroom">Bathroom</label>
                                                    <select class="form-control select2" name="bathroom" style="width: 100%;">
                                                        <option <?php if(isset($sellerdata)): ?> <?php if($sellerdata['bathroom']=='1'): ?>
                                                        selected
                                                    <?php endif; ?> <?php endif; ?> >1</option>
                                                    <option <?php if(isset($sellerdata)): ?> <?php if($sellerdata['bathroom']=='2'): ?>
                                                        selected
                                                    <?php endif; ?> <?php endif; ?> >2</option>
                                                    <option <?php if(isset($sellerdata)): ?> <?php if($sellerdata['bathroom']=='3'): ?>
                                                        selected
                                                    <?php endif; ?> <?php endif; ?> >3</option>
                                                    <option <?php if(isset($sellerdata)): ?> <?php if($sellerdata['bathroom']=='4'): ?>
                                                        selected
                                                    <?php endif; ?> <?php endif; ?> >4</option>
                                                    </select>
                                                </div>
                                            </div>

                                            <div class="col-md-3">
                                                <div class="form-group">
                                                    <label for="inputbalcony">Balcony</label>
                                                    <select class="form-control select2" name="balcony" style="width: 100%;">
                                                        <option <?php if(isset($sellerdata)): ?> <?php if($sellerdata['balcony']=='1'): ?>
                                                            selected
                                                        <?php endif; ?> <?php endif; ?> >1</option>
                                                        <option <?php if(isset($sellerdata)): ?> <?php if($sellerdata['balcony']=='2'): ?>
                                                            selected
                                                        <?php endif; ?> <?php endif; ?> >2</option>
                                                        <option <?php if(isset($sellerdata)): ?> <?php if($sellerdata['balcony']=='3'): ?>
                                                            selected
                                                        <?php endif; ?> <?php endif; ?> >3</option>
                                                        <option <?php if(isset($sellerdata)): ?> <?php if($sellerdata['balcony']=='4'): ?>
                                                            selected
                                                        <?php endif; ?> <?php endif; ?> >4</option>
                                                    </select>
                                                </div>
                                            </div>

                                            <div class="col-md-3">
                                                <div class="form-group">
                                                    <label for="Lift">Lift</label>
                                                    <select class="form-control select2" name="lift" style="width: 100%;">
                                                        <option <?php if(isset($sellerdata)): ?> <?php if($sellerdata['lift']=='1'): ?>
                                                            selected
                                                        <?php endif; ?> <?php endif; ?> >1</option>
                                                        <option <?php if(isset($sellerdata)): ?> <?php if($sellerdata['lift']=='2'): ?>
                                                            selected
                                                        <?php endif; ?> <?php endif; ?> >2</option>
                                                        <option <?php if(isset($sellerdata)): ?> <?php if($sellerdata['lift']=='3'): ?>
                                                            selected
                                                        <?php endif; ?> <?php endif; ?> >3</option>
                                                        <option <?php if(isset($sellerdata)): ?> <?php if($sellerdata['lift']=='4'): ?>
                                                            selected
                                                        <?php endif; ?> <?php endif; ?> >4</option>
                                                    </select>
                                                </div>
                                            </div>

                                            <div class="col-md-3">
                                                <div class="form-group">
                                                    <label for="Flat No">Parking</label>
                                                    <select class="form-control select2" name="parking" style="width: 100%;">
                                                        <option <?php if(isset($sellerdata)): ?> <?php if($sellerdata['parking']=='Sun Roof Parking'): ?>
                                                            selected
                                                        <?php endif; ?> <?php endif; ?> >Sun Roof Parking</option>
                                                        <option <?php if(isset($sellerdata)): ?> <?php if($sellerdata['parking']=='Under Ground Parking'): ?>
                                                            selected
                                                        <?php endif; ?> <?php endif; ?> >Under Ground Parking</option>
                                                        <option <?php if(isset($sellerdata)): ?> <?php if($sellerdata['parking']=='Floor Parking'): ?>
                                                            selected
                                                        <?php endif; ?> <?php endif; ?> >Floor Parking</option>
                                                    </select>
                                                </div>
                                            </div>
                                        </div>


                                        <div class="row">
                                            <div class="col-md-6">
                                                <div class="form-group">
                                                    <label>Apartment Type</label>
                                                    <select class="form-control select2" name="apartment_type" style="width: 100%;">
                                                        <option <?php if(isset($sellerdata)): ?> <?php if($sellerdata['apartment_type']=='Fully Furnished'): ?>
                                                        selected
                                                    <?php endif; ?> <?php endif; ?> >Fully Furnished</option>
                                                    <option <?php if(isset($sellerdata)): ?> <?php if($sellerdata['apartment_type']=='Un Furnished'): ?>
                                                        selected
                                                    <?php endif; ?> <?php endif; ?> >Un Furnished</option>
                                                    <option <?php if(isset($sellerdata)): ?> <?php if($sellerdata['apartment_type']=='Semi Furnished'): ?>
                                                        selected
                                                    <?php endif; ?> <?php endif; ?> >Semi Furnished</option>
                                                    </select>
                                                </div>
                                            </div>

                                            <div class="col-md-6">
                                                <div class="form-group">
                                                    <label for="inputSq.ft">Rental/Sell Price</label>
                                                    <input type="text" id=""
                                                    <?php if(isset($sellerdata)): ?>
                                                    value="<?php echo e($sellerdata['budget']); ?>"
                                                    <?php endif; ?>
                                                     name="budget" class="form-control">
                                                </div>
                                            </div>

                                        </div>


                                    </div>
                                    <div class="card-footer">
                                        <button type="submit" class="btn btn-primary">
                                            <?php if(isset($sellerdata)): ?>
                                            Update
                                                <?php else: ?>
                                                Submit
                                            <?php endif; ?>
                                            </button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </section>


        </div>
<?php $__env->stopSection(); ?>

    <script src="<?php echo e(asset('admin/plugins/jquery/jquery.min.js')); ?>"></script>
    <script src="<?php echo e(asset('admin/plugins/bootstrap/js/bootstrap.bundle.min.js')); ?>"></script>
    <script src="<?php echo e(asset('admin/plugins/jquery-validation/jquery.validate.min.js')); ?>"></script>
    <script src="<?php echo e(asset('admin/plugins/jquery-validation/additional-methods.min.js')); ?>"></script>
    <script src="<?php echo e(asset('admin/dist/js/adminlte.min2167.js?v=3.2.0')); ?>"></script>
    <script src="<?php echo e(asset('admin/dist/js/demo.js')); ?>"></script>

    <script>
        $(function() {
            $.validator.setDefaults({
                submitHandler: function() {
                    alert("Form successful submitted!");
                }
            });
            $('#quickForm').validate({
                rules: {
                    email: {
                        required: true,
                        email: true,
                    },
                    password: {
                        required: true,
                        minlength: 5
                    },
                    terms: {
                        required: true
                    },
                },
                messages: {
                    email: {
                        required: "Please enter a email address",
                        email: "Please enter a valid email address"
                    },
                    password: {
                        required: "Please provide a password",
                        minlength: "Your password must be at least 5 characters long"
                    },
                    terms: "Please accept our terms"
                },
                errorElement: 'span',
                errorPlacement: function(error, element) {
                    error.addClass('invalid-feedback');
                    element.closest('.form-group').append(error);
                },
                highlight: function(element, errorClass, validClass) {
                    $(element).addClass('is-invalid');
                },
                unhighlight: function(element, errorClass, validClass) {
                    $(element).removeClass('is-invalid');
                }
            });
        });
    </script>
</body>

</html>

<?php echo $__env->make('admin.layouts.admin_layouts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\Akash\git project\cms\resources\views/admin/seller/seller-form.blade.php ENDPATH**/ ?>