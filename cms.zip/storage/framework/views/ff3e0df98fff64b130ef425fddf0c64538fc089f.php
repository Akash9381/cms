<?php $__env->startSection('title','Land Loard Form'); ?>

<?php $__env->startSection('content'); ?>
        <div class="content-wrapper">

            <section class="content-header">
                <div class="container-fluid">
                    <div class="row mb-2">
                        <div class="col-sm-6">
                            <?php if(isset($landloardprofile)): ?>
                            <h1>Update Query Form</h1>
                            <?php else: ?>
                            <h1>New Query Form</h1>
                            <?php endif; ?>
                        </div>

                    </div>
                </div>
            </section>

            <section class="content">
                <div class="container-fluid">
                    <div class="row">

                        <div class="col-md-12">
                            <?php if(session()->has('success')): ?>
                            <div class="col-sm-12 alert alert-success">
                                <?php echo e(session()->get('success')); ?>

                            </div>
                            <?php endif; ?>
                            <?php if(session()->has('error')): ?>
                            <div class="col-sm-12 alert alert-danger">
                                <?php echo e(session()->get('error')); ?>

                            </div>
                            <?php endif; ?>
                            <div class="card card-primary">
                                <div class="card-header">
                                    <h3 class="card-title">Contact Details</h3>
                                </div>
                                <?php if(isset($landloardprofile)): ?>
                                <form method="POST" action="<?php echo e(url('admin/submitLandloard/'.$landloardprofile['id'])); ?>">
                                    <?php else: ?>
                                    <form method="POST" action="<?php echo e(url('admin/submitLandloard')); ?>">
                                <?php endif; ?>
                                    <?php echo csrf_field(); ?>
                                    <div class="card-body">

                                        <div class="row">
                                            <div class="col-md-3">
                                                <div class="form-group">
                                                    <label for="exampleInputName">Full Name</label>
                                                    <input type="text" name="name" <?php if(isset($landloardprofile)): ?>
                                                        value="<?php echo e($landloardprofile['name']); ?>"
                                                    <?php endif; ?> class="form-control" id="exampleInputName"
                                                        placeholder="Enter Name">
                                                </div>
                                            </div>

                                            <div class="col-md-3">
                                                <div class="form-group">
                                                    <label for="exampleInputEmail1">Email address</label>
                                                    <input type="email" <?php if(isset($landloardprofile)): ?>
                                                    value="<?php echo e($landloardprofile['email']); ?>"
                                                <?php endif; ?> name="email" class="form-control"
                                                        id="exampleInputEmail1" placeholder="Enter email">
                                                </div>
                                            </div>

                                            <div class="col-md-3">
                                                <div class="form-group">
                                                    <label for="exampleInputNumber">Contact Number</label>
                                                    <input type="tel" name="phone" <?php if(isset($landloardprofile)): ?>
                                                    value="<?php echo e($landloardprofile['phone']); ?>"
                                                <?php endif; ?> pattern="[789][0-9]{9}" class="form-control"
                                                        id="exampleInputNumber" placeholder="Contact Number">
                                                </div>
                                            </div>

                                            <div class="col-md-3">
                                                <div class="form-group">
                                                    <label for="exampleInputNumber">Date</label>
                                                    <div class="input-group date" id="reservationdate"
                                                        data-target-input="nearest">
                                                        <input type="text" name="date"
                                                        <?php if(isset($landloardprofile)): ?>
                                                        value="<?php echo e(\Carbon\Carbon::parse($landloardprofile->date)->format('m/d/Y')); ?>"
                                                    <?php endif; ?>
                                                            class="form-control datetimepicker-input"
                                                            data-target="#reservationdate" />
                                                        <div class="input-group-append" data-target="#reservationdate"
                                                            data-toggle="datetimepicker">
                                                            <div class="input-group-text"><i
                                                                    class="fa fa-calendar"></i></div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                
                            </div>
                        </div>
                    </div>
                </div>
            </section>


            <section class="content">
                <div class="container-fluid">
                    <div class="row">

                        <div class="col-md-12">

                            <div class="card card-primary">
                                <div class="card-header">
                                    <h3 class="card-title">Apartment Details</h3>
                                </div>

                                
                                    <div class="card-body">

                                        <div class="row">
                                            <div class="col-md-6">
                                                <div class="form-group">
                                                    <label>Apartment</label>
                                                    <select class="form-control select2" name="apartment" style="width: 100%;">
                                                        <option <?php if(isset($landloardprofile)): ?> <?php if($landloardprofile['apartment']=='Studio'): ?>
                                                            selected
                                                        <?php endif; ?> <?php endif; ?> >Studio</option>
                                                        <option <?php if(isset($landloardprofile)): ?> <?php if($landloardprofile['apartment']=='1 BHK'): ?>
                                                            selected
                                                        <?php endif; ?> <?php endif; ?>>1 BHK</option>
                                                        <option <?php if(isset($landloardprofile)): ?> <?php if($landloardprofile['apartment']=='2 BHK'): ?>
                                                            selected
                                                        <?php endif; ?> <?php endif; ?>>2 BHK</option>
                                                        <option <?php if(isset($landloardprofile)): ?> <?php if($landloardprofile['apartment']=='3 BHK'): ?>
                                                            selected
                                                        <?php endif; ?> <?php endif; ?>>3 BHK</option>
                                                        <option <?php if(isset($landloardprofile)): ?> <?php if($landloardprofile['apartment']=='4 BHK'): ?>
                                                            selected
                                                        <?php endif; ?> <?php endif; ?>>4 BHK</option>
                                                        <option <?php if(isset($landloardprofile)): ?> <?php if($landloardprofile['apartment']=='5 BHK'): ?>
                                                            selected
                                                        <?php endif; ?> <?php endif; ?>>5 BHK</option>
                                                        <option <?php if(isset($landloardprofile)): ?> <?php if($landloardprofile['apartment']=='Penthouse'): ?>
                                                            selected
                                                        <?php endif; ?> <?php endif; ?>>Penthouse</option>
                                                    </select>
                                                </div>
                                            </div>

                                            <div class="col-md-6">
                                                <div class="form-group">
                                                    <label for="inputSq.ft">Sq.ft</label>
                                                    <input type="text" id="" <?php if(isset($landloardprofile)): ?>
                                                    value="<?php echo e($landloardprofile['area']); ?>"
                                                <?php endif; ?> name="area" class="form-control">
                                                </div>
                                            </div>

                                        </div>


                                        <div class="row">
                                            <div class="col-md-3">
                                                <div class="form-group">
                                                    <label for="inputSociety">Society</label>
                                                    <input type="text" id="" <?php if(isset($landloardprofile)): ?>
                                                    value="<?php echo e($landloardprofile['society']); ?>"
                                                <?php endif; ?> name="society" class="form-control">
                                                </div>
                                            </div>

                                            <div class="col-md-3">
                                                <div class="form-group">
                                                    <label for="inputBlock">Block/Tower</label>
                                                    <input type="text" id="" <?php if(isset($landloardprofile)): ?>
                                                    value="<?php echo e($landloardprofile['block']); ?>"
                                                <?php endif; ?> name="block" class="form-control">
                                                </div>
                                            </div>

                                            <div class="col-md-3">
                                                <div class="form-group">
                                                    <label for="Floor">Floor</label>
                                                    <input type="text" id="" <?php if(isset($landloardprofile)): ?>
                                                    value="<?php echo e($landloardprofile['floor']); ?>"
                                                <?php endif; ?> name="floor" class="form-control">
                                                </div>
                                            </div>

                                            <div class="col-md-3">
                                                <div class="form-group">
                                                    <label for="Flat No">Flat No</label>
                                                    <input type="text" id="" <?php if(isset($landloardprofile)): ?>
                                                    value="<?php echo e($landloardprofile['flat_no']); ?>"
                                                <?php endif; ?> name="flat_no" class="form-control">
                                                </div>
                                            </div>
                                        </div>


                                        <div class="row">
                                            <div class="col-md-3">
                                                <div class="form-group">
                                                    <label for="inputBathroom">Bathroom</label>
                                                    <select class="form-control select2" name="bathroom" style="width: 100%;">
                                                        <option <?php if(isset($landloardprofile)): ?> <?php if($landloardprofile['bathroom']=='1'): ?>
                                                            selected
                                                        <?php endif; ?> <?php endif; ?> >1</option>
                                                        <option <?php if(isset($landloardprofile)): ?> <?php if($landloardprofile['bathroom']=='2'): ?>
                                                            selected
                                                        <?php endif; ?> <?php endif; ?> >2</option>
                                                        <option <?php if(isset($landloardprofile)): ?> <?php if($landloardprofile['bathroom']=='3'): ?>
                                                            selected
                                                        <?php endif; ?> <?php endif; ?> >3</option>
                                                        <option <?php if(isset($landloardprofile)): ?> <?php if($landloardprofile['bathroom']=='4'): ?>
                                                            selected
                                                        <?php endif; ?> <?php endif; ?> >4</option>
                                                    </select>
                                                </div>
                                            </div>

                                            <div class="col-md-3">
                                                <div class="form-group">
                                                    <label for="inputbalcony">Balcony</label>
                                                    <select class="form-control select2" name="balcony" style="width: 100%;">
                                                        <option <?php if(isset($landloardprofile)): ?> <?php if($landloardprofile['balcony']=='1'): ?>
                                                            selected
                                                        <?php endif; ?> <?php endif; ?> >1</option>
                                                        <option <?php if(isset($landloardprofile)): ?> <?php if($landloardprofile['balcony']=='2'): ?>
                                                            selected
                                                        <?php endif; ?> <?php endif; ?> >2</option>
                                                        <option <?php if(isset($landloardprofile)): ?> <?php if($landloardprofile['balcony']=='3'): ?>
                                                            selected
                                                        <?php endif; ?> <?php endif; ?> >3</option>
                                                        <option <?php if(isset($landloardprofile)): ?> <?php if($landloardprofile['balcony']=='4'): ?>
                                                            selected
                                                        <?php endif; ?> <?php endif; ?> >4</option>
                                                    </select>
                                                </div>
                                            </div>

                                            <div class="col-md-3">
                                                <div class="form-group">
                                                    <label for="Lift">Lift</label>
                                                    <select class="form-control select2" name="lift" style="width: 100%;">
                                                        <option <?php if(isset($landloardprofile)): ?> <?php if($landloardprofile['lift']=='1'): ?>
                                                            selected
                                                        <?php endif; ?> <?php endif; ?> >1</option>
                                                        <option <?php if(isset($landloardprofile)): ?> <?php if($landloardprofile['lift']=='2'): ?>
                                                            selected
                                                        <?php endif; ?> <?php endif; ?> >2</option>
                                                        <option <?php if(isset($landloardprofile)): ?> <?php if($landloardprofile['lift']=='3'): ?>
                                                            selected
                                                        <?php endif; ?> <?php endif; ?> >3</option>
                                                        <option <?php if(isset($landloardprofile)): ?> <?php if($landloardprofile['lift']=='4'): ?>
                                                            selected
                                                        <?php endif; ?> <?php endif; ?> >4</option>
                                                    </select>
                                                </div>
                                            </div>

                                            <div class="col-md-3">
                                                <div class="form-group">
                                                    <label for="Flat No">Parking</label>
                                                    <select class="form-control select2" name="parking" style="width: 100%;">
                                                        <option <?php if(isset($landloardprofile)): ?> <?php if($landloardprofile['parking']=='Sun Roof Parking'): ?>
                                                            selected
                                                        <?php endif; ?> <?php endif; ?> >Sun Roof Parking</option>
                                                        <option <?php if(isset($landloardprofile)): ?> <?php if($landloardprofile['parking']=='Under Ground Parking'): ?>
                                                            selected
                                                        <?php endif; ?> <?php endif; ?> >Under Ground Parking</option>
                                                        <option <?php if(isset($landloardprofile)): ?> <?php if($landloardprofile['parking']=='Floor Parking'): ?>
                                                            selected
                                                        <?php endif; ?> <?php endif; ?> >Floor Parking</option>
                                                    </select>
                                                </div>
                                            </div>
                                        </div>


                                        <div class="row">
                                            <div class="col-md-6">
                                                <div class="form-group">
                                                    <label>Furnished</label>
                                                    <select class="form-control select2" name="apartment_type" style="width: 100%;">
                                                        <option <?php if(isset($landloardprofile)): ?> <?php if($landloardprofile['apartment_type']=='Fully Furnished'): ?>
                                                            selected
                                                        <?php endif; ?> <?php endif; ?> >Fully Furnished</option>
                                                        <option <?php if(isset($landloardprofile)): ?> <?php if($landloardprofile['apartment_type']=='Un Furnished'): ?>
                                                            selected
                                                        <?php endif; ?> <?php endif; ?> >Un Furnished</option>
                                                        <option <?php if(isset($landloardprofile)): ?> <?php if($landloardprofile['apartment_type']=='Semi Furnished'): ?>
                                                            selected
                                                        <?php endif; ?> <?php endif; ?> >Semi Furnished</option>
                                                    </select>
                                                </div>
                                            </div>

                                            <div class="col-md-6">
                                                <div class="form-group">
                                                    <label for="inputSq.ft">Rental/Sell Price(thousands)</label>
                                                    <input type="text" id="" <?php if(isset($landloardprofile)): ?>
                                                    value="<?php echo e($landloardprofile['budget']); ?>"
                                                <?php endif; ?> name="budget" class="form-control">
                                                </div>
                                            </div>
                                        </div>

                                    </div>
                                    <div class="card-footer">
                                        <button type="submit" class="btn btn-primary"><?php if(isset($landloardprofile)): ?>
                                            Update
                                           <?php else: ?>
                                           Submit
                                        <?php endif; ?> </button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
        </div>
<?php $__env->stopSection(); ?>

    <script src="<?php echo e(asset('admin/plugins/jquery/jquery.min.js')); ?>"></script>
    <script src="<?php echo e(asset('admin/plugins/bootstrap/js/bootstrap.bundle.min.js')); ?>"></script>
    <script src="<?php echo e(asset('admin/plugins/select2/js/select2.full.min.js')); ?>"></script>
    <script src="<?php echo e(asset('admin/plugins/bootstrap4-duallistbox/jquery.bootstrap-duallistbox.min.js')); ?>"></script>
    <script src="<?php echo e(asset('admin/plugins/moment/moment.min.js')); ?>"></script>
    <script src="<?php echo e(asset('admin/plugins/inputmask/jquery.inputmask.min.js')); ?>"></script>
    <script src="<?php echo e(asset('admin/plugins/daterangepicker/daterangepicker.js')); ?>"></script>
    <script src="<?php echo e(asset('admin/plugins/bootstrap-colorpicker/js/bootstrap-colorpicker.min.js')); ?>"></script>
    <script src="<?php echo e(asset('admin/plugins/tempusdominus-bootstrap-4/js/tempusdominus-bootstrap-4.min.js')); ?>"></script>
    <script src="<?php echo e(asset('admin/plugins/bootstrap-switch/js/bootstrap-switch.min.js')); ?>"></script>
    <script src="<?php echo e(asset('admin/plugins/bs-stepper/js/bs-stepper.min.js')); ?>"></script>
    <script src="<?php echo e(asset('admin/plugins/dropzone/min/dropzone.min.js')); ?>"></script>
    <script src="<?php echo e(asset('admin/dist/js/adminlte.min2167.js?v=3.2.0')); ?>"></script>
    <script src="<?php echo e(asset('admin/dist/js/demo.js')); ?>"></script>

    <script>
        $(function() {
            //Initialize Select2 Elements
            $('.select2').select2()

            //Initialize Select2 Elements
            $('.select2bs4').select2({
                theme: 'bootstrap4'
            })

            //Datemask dd/mm/yyyy
            $('#datemask').inputmask('dd/mm/yyyy', {
                'placeholder': 'dd/mm/yyyy'
            })
            //Datemask2 mm/dd/yyyy
            $('#datemask2').inputmask('mm/dd/yyyy', {
                'placeholder': 'mm/dd/yyyy'
            })
            //Money Euro
            $('[data-mask]').inputmask()

            //Date picker
            $('#reservationdate').datetimepicker({
                format: 'L'
            });

            //Date and time picker
            $('#reservationdatetime').datetimepicker({
                icons: {
                    time: 'far fa-clock'
                }
            });

            //Date range picker
            $('#reservation').daterangepicker()
            //Date range picker with time picker
            $('#reservationtime').daterangepicker({
                timePicker: true,
                timePickerIncrement: 30,
                locale: {
                    format: 'MM/DD/YYYY hh:mm A'
                }
            })
            //Date range as a button
            $('#daterange-btn').daterangepicker({
                    ranges: {
                        'Today': [moment(), moment()],
                        'Yesterday': [moment().subtract(1, 'days'), moment().subtract(1, 'days')],
                        'Last 7 Days': [moment().subtract(6, 'days'), moment()],
                        'Last 30 Days': [moment().subtract(29, 'days'), moment()],
                        'This Month': [moment().startOf('month'), moment().endOf('month')],
                        'Last Month': [moment().subtract(1, 'month').startOf('month'), moment().subtract(1,
                            'month').endOf('month')]
                    },
                    startDate: moment().subtract(29, 'days'),
                    endDate: moment()
                },
                function(start, end) {
                    $('#reportrange span').html(start.format('MMMM D, YYYY') + ' - ' + end.format(
                        'MMMM D, YYYY'))
                }
            )

            //Timepicker
            $('#timepicker').datetimepicker({
                format: 'LT'
            })

            //Bootstrap Duallistbox
            $('.duallistbox').bootstrapDualListbox()

            //Colorpicker
            $('.my-colorpicker1').colorpicker()
            //color picker with addon
            $('.my-colorpicker2').colorpicker()

            $('.my-colorpicker2').on('colorpickerChange', function(event) {
                $('.my-colorpicker2 .fa-square').css('color', event.color.toString());
            })

            $("input[data-bootstrap-switch]").each(function() {
                $(this).bootstrapSwitch('state', $(this).prop('checked'));
            })

        })
        // BS-Stepper Init
        document.addEventListener('DOMContentLoaded', function() {
            window.stepper = new Stepper(document.querySelector('.bs-stepper'))
        })

        // DropzoneJS Demo Code Start
        Dropzone.autoDiscover = false

        // Get the template HTML and remove it from the doumenthe template HTML and remove it from the doument
        var previewNode = document.querySelector("#template")
        previewNode.id = ""
        var previewTemplate = previewNode.parentNode.innerHTML
        previewNode.parentNode.removeChild(previewNode)

        var myDropzone = new Dropzone(document.body, { // Make the whole body a dropzone
            url: "/target-url", // Set the url
            thumbnailWidth: 80,
            thumbnailHeight: 80,
            parallelUploads: 20,
            previewTemplate: previewTemplate,
            autoQueue: false, // Make sure the files aren't queued until manually added
            previewsContainer: "#previews", // Define the container to display the previews
            clickable: ".fileinput-button" // Define the element that should be used as click trigger to select files.
        })

        myDropzone.on("addedfile", function(file) {
            // Hookup the start button
            file.previewElement.querySelector(".start").onclick = function() {
                myDropzone.enqueueFile(file)
            }
        })

        // Update the total progress bar
        myDropzone.on("totaluploadprogress", function(progress) {
            document.querySelector("#total-progress .progress-bar").style.width = progress + "%"
        })

        myDropzone.on("sending", function(file) {
            // Show the total progress bar when upload starts
            document.querySelector("#total-progress").style.opacity = "1"
            // And disable the start button
            file.previewElement.querySelector(".start").setAttribute("disabled", "disabled")
        })

        // Hide the total progress bar when nothing's uploading anymore
        myDropzone.on("queuecomplete", function(progress) {
            document.querySelector("#total-progress").style.opacity = "0"
        })

        // Setup the buttons for all transfers
        // The "add files" button doesn't need to be setup because the config
        // `clickable` has already been specified.
        document.querySelector("#actions .start").onclick = function() {
            myDropzone.enqueueFiles(myDropzone.getFilesWithStatus(Dropzone.ADDED))
        }
        document.querySelector("#actions .cancel").onclick = function() {
            myDropzone.removeAllFiles(true)
        }
        // DropzoneJS Demo Code End
    </script>
</body>

</html>

<?php echo $__env->make('admin.layouts.admin_layouts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\Akash\git project\cms\resources\views/admin/landloard/landloard-form.blade.php ENDPATH**/ ?>