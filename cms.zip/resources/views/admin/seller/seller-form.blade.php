@extends('admin.layouts.admin_layouts')
@section('title','Seller Form')
@section('content')


        <div class="content-wrapper">

            <section class="content-header">
                <div class="container-fluid">
                    <div class="row mb-2">
                        <div class="col-sm-6">
                            <h1>New Query Form</h1>
                        </div>
                    </div>
                </div>
            </section>

            <section class="content">
                <div class="container-fluid">
                    <div class="row">

                        <div class="col-md-12">
                            @if (session()->has('success'))
                            <div class="col-sm-12 alert alert-success">
                                {{session()->get('success')}}
                            </div>
                            @endif
                            @if (session()->has('error'))
                            <div class="col-sm-12 alert alert-danger">
                                {{session()->get('error')}}
                            </div>
                            @endif
                            <div class="card card-primary">
                                <div class="card-header">
                                    <h3 class="card-title">Contact Details</h3>
                                </div>
                                @isset($sellerdata)
                                <form method="POST" action="{{url('admin/submitseller/'.$sellerdata['id'])}}">
                                    @else
                                    <form method="POST" action="{{url('admin/submitseller')}}">
                                @endisset
                                    @csrf
                                    <div class="card-body">

                                        <div class="row">
                                            <div class="col-md-3">
                                                <div class="form-group">
                                                    <label for="exampleInputName">Full Name</label>
                                                    <input type="text" name="name" @isset($sellerdata)
                                                   value ="{{$sellerdata['name']}}"
                                                @endisset class="form-control" id="exampleInputName"
                                                        placeholder="Enter Name">
                                                </div>
                                            </div>

                                            <div class="col-md-3">
                                                <div class="form-group">
                                                    <label for="exampleInputEmail1">Email address</label>
                                                    <input type="email" @isset($sellerdata)
                                                    value ="{{$sellerdata['email']}}"
                                                 @endisset name="email" class="form-control"
                                                        id="exampleInputEmail1" placeholder="Enter email">
                                                </div>
                                            </div>

                                            <div class="col-md-3">
                                                <div class="form-group">
                                                    <label for="exampleInputNumber">Contact Number</label>
                                                    <input type="tel" @isset($sellerdata)
                                                    value ="{{$sellerdata['phone']}}"
                                                 @endisset name="phone" pattern="[789][0-9]{9}" class="form-control"
                                                        id="exampleInputNumber" placeholder="Contact Number">
                                                </div>
                                            </div>

                                            <div class="col-md-3">
                                                <div class="form-group">
                                                    <label for="exampleInputNumber">Date</label>
                                                    <div class="input-group date" id="reservationdate"
                                                        data-target-input="nearest">
                                                        <input type="text" name="date"
                                                        @isset($sellerdata)
                                                        value="{{ \Carbon\Carbon::parse($sellerdata->date)->format('m/d/Y')}}"
                                                @endisset
                                                            class="form-control datetimepicker-input"
                                                            data-target="#reservationdate" />
                                                        <div class="input-group-append" data-target="#reservationdate"
                                                            data-toggle="datetimepicker">
                                                            <div class="input-group-text"><i
                                                                    class="fa fa-calendar"></i></div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                {{-- </form> --}}
                            </div>
                        </div>
                    </div>
                </div>
            </section>


            <section class="content">
                <div class="container-fluid">
                    <div class="row">

                        <div class="col-md-12">

                            <div class="card card-primary">
                                <div class="card-header">
                                    <h3 class="card-title">Apartment Details</h3>
                                </div>

                                {{-- <form> --}}
                                    <div class="card-body">

                                        <div class="row">
                                            <div class="col-md-6">
                                                <div class="form-group">
                                                    <label>Apartment</label>
                                                    <select class="form-control select2" name="apartment" style="width: 100%;">
                                                        <option @isset($sellerdata) @if ($sellerdata['apartment']=='Studio')
                                                        selected
                                                    @endif @endisset >Studio</option>
                                                    <option @isset($sellerdata) @if ($sellerdata['apartment']=='1 BHK')
                                                        selected
                                                    @endif @endisset>1 BHK</option>
                                                    <option @isset($sellerdata) @if ($sellerdata['apartment']=='2 BHK')
                                                        selected
                                                    @endif @endisset>2 BHK</option>
                                                    <option @isset($sellerdata) @if ($sellerdata['apartment']=='3 BHK')
                                                        selected
                                                    @endif @endisset>3 BHK</option>
                                                    <option @isset($sellerdata) @if ($sellerdata['apartment']=='4 BHK')
                                                        selected
                                                    @endif @endisset>4 BHK</option>
                                                    <option @isset($sellerdata) @if ($sellerdata['apartment']=='5 BHK')
                                                        selected
                                                    @endif @endisset>5 BHK</option>
                                                    <option @isset($sellerdata) @if ($sellerdata['apartment']=='Penthouse')
                                                        selected
                                                    @endif @endisset>Penthouse</option>
                                                    </select>
                                                </div>
                                            </div>

                                            <div class="col-md-6">
                                                <div class="form-group">
                                                    <label for="inputSq.ft">Sq.ft</label>
                                                    <input type="text" id="" @isset($sellerdata)
                                                    value="{{$sellerdata['area']}}"
                                                    @endisset  name="area" class="form-control">
                                                </div>
                                            </div>

                                        </div>


                                        <div class="row">
                                            <div class="col-md-3">
                                                <div class="form-group">
                                                    <label for="inputSociety">Society</label>
                                                    <input type="text" id=""
                                                    @isset($sellerdata)
                                                    value="{{$sellerdata['society']}}"
                                                    @endisset
                                                     name="society" class="form-control">
                                                </div>
                                            </div>

                                            <div class="col-md-3">
                                                <div class="form-group">
                                                    <label for="inputBlock">Block/Tower</label>
                                                    <input type="text" id=""
                                                    @isset($sellerdata)
                                                    value="{{$sellerdata['block']}}"
                                                    @endisset
                                                     name="block" class="form-control">
                                                </div>
                                            </div>

                                            <div class="col-md-3">
                                                <div class="form-group">
                                                    <label for="Floor">Floor</label>
                                                    <input type="text" id="" name="floor"
                                                    @isset($sellerdata)
                                                    value="{{$sellerdata['floor']}}"
                                                    @endisset class="form-control">
                                                </div>
                                            </div>

                                            <div class="col-md-3">
                                                <div class="form-group">
                                                    <label for="Flat No">Flat No</label>
                                                    <input type="text" id=""
                                                    @isset($sellerdata)
                                                    value="{{$sellerdata['flat_no']}}"
                                                    @endisset
                                                     name="flat_no" class="form-control">
                                                </div>
                                            </div>
                                        </div>


                                        <div class="row">
                                            <div class="col-md-3">
                                                <div class="form-group">
                                                    <label for="inputBathroom">Bathroom</label>
                                                    <select class="form-control select2" name="bathroom" style="width: 100%;">
                                                        <option @isset($sellerdata) @if ($sellerdata['bathroom']=='1')
                                                        selected
                                                    @endif @endisset >1</option>
                                                    <option @isset($sellerdata) @if ($sellerdata['bathroom']=='2')
                                                        selected
                                                    @endif @endisset >2</option>
                                                    <option @isset($sellerdata) @if ($sellerdata['bathroom']=='3')
                                                        selected
                                                    @endif @endisset >3</option>
                                                    <option @isset($sellerdata) @if ($sellerdata['bathroom']=='4')
                                                        selected
                                                    @endif @endisset >4</option>
                                                    </select>
                                                </div>
                                            </div>

                                            <div class="col-md-3">
                                                <div class="form-group">
                                                    <label for="inputbalcony">Balcony</label>
                                                    <select class="form-control select2" name="balcony" style="width: 100%;">
                                                        <option @isset($sellerdata) @if ($sellerdata['balcony']=='1')
                                                            selected
                                                        @endif @endisset >1</option>
                                                        <option @isset($sellerdata) @if ($sellerdata['balcony']=='2')
                                                            selected
                                                        @endif @endisset >2</option>
                                                        <option @isset($sellerdata) @if ($sellerdata['balcony']=='3')
                                                            selected
                                                        @endif @endisset >3</option>
                                                        <option @isset($sellerdata) @if ($sellerdata['balcony']=='4')
                                                            selected
                                                        @endif @endisset >4</option>
                                                    </select>
                                                </div>
                                            </div>

                                            <div class="col-md-3">
                                                <div class="form-group">
                                                    <label for="Lift">Lift</label>
                                                    <select class="form-control select2" name="lift" style="width: 100%;">
                                                        <option @isset($sellerdata) @if ($sellerdata['lift']=='1')
                                                            selected
                                                        @endif @endisset >1</option>
                                                        <option @isset($sellerdata) @if ($sellerdata['lift']=='2')
                                                            selected
                                                        @endif @endisset >2</option>
                                                        <option @isset($sellerdata) @if ($sellerdata['lift']=='3')
                                                            selected
                                                        @endif @endisset >3</option>
                                                        <option @isset($sellerdata) @if ($sellerdata['lift']=='4')
                                                            selected
                                                        @endif @endisset >4</option>
                                                    </select>
                                                </div>
                                            </div>

                                            <div class="col-md-3">
                                                <div class="form-group">
                                                    <label for="Flat No">Parking</label>
                                                    <select class="form-control select2" name="parking" style="width: 100%;">
                                                        <option @isset($sellerdata) @if ($sellerdata['parking']=='Sun Roof Parking')
                                                            selected
                                                        @endif @endisset >Sun Roof Parking</option>
                                                        <option @isset($sellerdata) @if ($sellerdata['parking']=='Under Ground Parking')
                                                            selected
                                                        @endif @endisset >Under Ground Parking</option>
                                                        <option @isset($sellerdata) @if ($sellerdata['parking']=='Floor Parking')
                                                            selected
                                                        @endif @endisset >Floor Parking</option>
                                                    </select>
                                                </div>
                                            </div>
                                        </div>


                                        <div class="row">
                                            <div class="col-md-6">
                                                <div class="form-group">
                                                    <label>Apartment Type</label>
                                                    <select class="form-control select2" name="apartment_type" style="width: 100%;">
                                                        <option @isset($sellerdata) @if ($sellerdata['apartment_type']=='Fully Furnished')
                                                        selected
                                                    @endif @endisset >Fully Furnished</option>
                                                    <option @isset($sellerdata) @if ($sellerdata['apartment_type']=='Un Furnished')
                                                        selected
                                                    @endif @endisset >Un Furnished</option>
                                                    <option @isset($sellerdata) @if ($sellerdata['apartment_type']=='Semi Furnished')
                                                        selected
                                                    @endif @endisset >Semi Furnished</option>
                                                    </select>
                                                </div>
                                            </div>

                                            <div class="col-md-6">
                                                <div class="form-group">
                                                    <label for="inputSq.ft">Rental/Sell Price</label>
                                                    <input type="text" id=""
                                                    @isset($sellerdata)
                                                    value="{{$sellerdata['budget']}}"
                                                    @endisset
                                                     name="budget" class="form-control">
                                                </div>
                                            </div>

                                        </div>


                                    </div>
                                    <div class="card-footer">
                                        <button type="submit" class="btn btn-primary">
                                            @isset($sellerdata)
                                            Update
                                                @else
                                                Submit
                                            @endisset
                                            </button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </section>


        </div>
@endsection

    <script src="{{asset('admin/plugins/jquery/jquery.min.js')}}"></script>
    <script src="{{asset('admin/plugins/bootstrap/js/bootstrap.bundle.min.js')}}"></script>
    <script src="{{asset('admin/plugins/jquery-validation/jquery.validate.min.js')}}"></script>
    <script src="{{asset('admin/plugins/jquery-validation/additional-methods.min.js')}}"></script>
    <script src="{{asset('admin/dist/js/adminlte.min2167.js?v=3.2.0')}}"></script>
    <script src="{{asset('admin/dist/js/demo.js')}}"></script>

    <script>
        $(function() {
            $.validator.setDefaults({
                submitHandler: function() {
                    alert("Form successful submitted!");
                }
            });
            $('#quickForm').validate({
                rules: {
                    email: {
                        required: true,
                        email: true,
                    },
                    password: {
                        required: true,
                        minlength: 5
                    },
                    terms: {
                        required: true
                    },
                },
                messages: {
                    email: {
                        required: "Please enter a email address",
                        email: "Please enter a valid email address"
                    },
                    password: {
                        required: "Please provide a password",
                        minlength: "Your password must be at least 5 characters long"
                    },
                    terms: "Please accept our terms"
                },
                errorElement: 'span',
                errorPlacement: function(error, element) {
                    error.addClass('invalid-feedback');
                    element.closest('.form-group').append(error);
                },
                highlight: function(element, errorClass, validClass) {
                    $(element).addClass('is-invalid');
                },
                unhighlight: function(element, errorClass, validClass) {
                    $(element).removeClass('is-invalid');
                }
            });
        });
    </script>
</body>

</html>
